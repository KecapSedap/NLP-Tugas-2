from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
import time

start = time.perf_counter()
print("Memulai proses Stemming...")

factory = StemmerFactory()
stemmer = factory.create_stemmer()

f = open(f"10mb.txt", "r", encoding='utf8')
teks = f.read()
f.close()

teks = teks.split(".")

for i in teks:
    teks_stem = stemmer.stem(i)
# print(teks_stem)

finish = time.perf_counter()
waktu = round(finish-start, 2)
print(f"Program Selesai Dalam {waktu} Detik!")

from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
import multiprocessing as mp
import time


def test(kalimat):
    factory = StemmerFactory()
    stemmer = factory.create_stemmer()
    stemmer.stem(kalimat)


def Divide(a):
    b = []
    c = ""
    chck = 0
    for i in a:
        chck += 1
        if chck < round(len(a)/2):
            c += i
        else:
            b.append(c)
            c = ""
            chck = 0

    b[len(b)-1] += c
    c = ""

    return b


def Stem(b):
    processes = []
    for i in b:
        p = mp.Process(target=test, args=(i, ))
        p.start()

        processes.append(p)

    for process in processes:
        process.join()


if __name__ == "__main__":
    print("Memulai proses Multiprocessing Stemming...")

    f = open(f"10mb.txt", "r", encoding='utf8')
    teks = f.read()
    f.close()

    a = teks.split(".")
    b = Divide(a)

    start = time.perf_counter()

    Stem(b)

    finish = time.perf_counter()
    waktu = round(finish-start, 2)
    print(f"Program Selesai Dalam {waktu} Detik!")
